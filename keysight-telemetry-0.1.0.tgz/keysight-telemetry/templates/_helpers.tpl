{{- define "kt.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "kt.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "kt.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "kt.labels" -}}
app.kubernetes.io/name: {{ include "kt.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}

{{- define "kt.web.fullname" -}}{{ include "kt.fullname" . }}-web{{- end -}}
{{- define "kt.api.fullname" -}}{{ include "kt.fullname" . }}-api{{- end -}}
{{- define "kt.pg.fullname"  -}}{{ include "kt.fullname" . }}-postgres{{- end -}}

{{- define "kt.image.tag" -}}{{ .Values.image.tag | default .Chart.AppVersion }}{{- end -}}

{{- define "kt.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "kt.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "kt.pg.secretName" -}}
{{- if .Values.postgres.existingSecret -}}{{ .Values.postgres.existingSecret }}{{- else -}}{{ include "kt.pg.fullname" . }}{{- end -}}
{{- end -}}
